import { Route, BrowserRouter, Routes } from 'react-router-dom';
import './App.css';
import Login from './components/Login/login';
import Signup from './components/Signup/signup';
import Homepage from './components/Homepage/homepage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login/>}/>
        <Route path="signup" element={<Signup/>} />  
        <Route path="home" element={<Homepage/>} />     
      </Routes>
    </BrowserRouter>
  );
}


export default App;
