import React from "react";
import './login.css'

class Login extends React.Component {
    render() {
      return <div className="parent clearfix">
      <div className="bg-illustration">
        {/* <img src="https://i.ibb.co/Pcg0Pk1/logo.png" alt="logo" /> */}
        <h1 className="bank_title">AWSome Bank</h1>
        <div className="burger-btn">
          <span />
          <span />
          <span />
        </div>
      </div>
      <div className="login">
        <div className="container">
          <h1>
            Login to access to
            <br />
            your account
          </h1>
          <div className="login-form">
            <form action="">
              <input type="email" placeholder="E-mail Address" />
              <input type="password" placeholder="Password" />
              <button type="submit">LOG-IN</button>
            </form>
            <a className="signup" href="/signup">SIGN-UP</a>
          </div>
        </div>
      </div>
    </div>
    
    
    }
}

export default Login;